import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    
    //Read the Count created by Content Modifier
    def completed_dataCount = message.getProperty("Completed_DataCount")
    
    //Get Message processing log
    def messageLog = messageLogFactory.getMessageLog(message)
    
    //Monitor visibility{
    messageLog.addCustomHeaderProperty("Completed_DataCount", completed_dataCount)
    

    return message;
}